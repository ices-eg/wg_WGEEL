source("../run.compare.R")
run.compare("nscod")
