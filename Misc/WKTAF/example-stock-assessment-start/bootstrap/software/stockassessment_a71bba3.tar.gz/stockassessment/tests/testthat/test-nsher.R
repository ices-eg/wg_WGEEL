source("../run.compare.R")
run.compare("nsher")