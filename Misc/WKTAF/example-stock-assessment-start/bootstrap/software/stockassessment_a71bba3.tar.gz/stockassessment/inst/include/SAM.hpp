#ifndef SAM_HPP
#define SAM_HPP

#include "tiny_adflex.hpp"
#include "zeroin.hpp"
#include "pnorm.hpp"
#include "spline.hpp"
#include "toF.hpp"
#include "define.hpp"
#include "biopar.hpp"
#include "derived.hpp"
#include "f.hpp"
#include "predn.hpp"
#include "n.hpp"
#include "predobs.hpp"
#include "obs.hpp"
#include "perRecruit.hpp"
#include "hcr.hpp"

#endif
